import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { ScheduleAllModule, RecurrenceEditorAllModule } from '@syncfusion/ej2-angular-schedule';
import { AppComponent } from './app.component';
import {loadCldr, setCulture, setCurrencyCode} from '@syncfusion/ej2-base';
@NgModule({
  imports: [BrowserModule, ScheduleAllModule, RecurrenceEditorAllModule  ],
  declarations: [AppComponent],
  bootstrap: [AppComponent]
})
export class AppModule { }
