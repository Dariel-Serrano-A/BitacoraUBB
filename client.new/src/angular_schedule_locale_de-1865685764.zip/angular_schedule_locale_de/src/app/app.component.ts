import { Component, OnInit, ViewEncapsulation, ViewChild } from '@angular/core';
import {
  EventSettingsModel, DayService, WeekService, WorkWeekService, MonthService,
  AgendaService, ScheduleComponent, View, ResizeService, DragAndDropService
} from '@syncfusion/ej2-angular-schedule';
import { L10n, loadCldr } from '@syncfusion/ej2-base';

declare let require: Function;
loadCldr(
  require('../../node_modules/cldr-data/supplemental/numberingSystems.json'),
  require('../../node_modules/cldr-data/main/de/ca-gregorian.json'),
  require('../../node_modules/cldr-data/main/de/currencies.json'),
  require('../../node_modules/cldr-data/main/de/numbers.json'),
  require('../../node_modules/cldr-data/main/de/timeZoneNames.json')
);
L10n.load({
  "de": {
    "schedule": {
      "day": "Tag",
      "week": "Woche",
      "workWeek": "Arbeitswoche",
      "month": "Monat",
      "agenda": "Agenda",
      "weekAgenda": "Wochenprogramm",
      "workWeekAgenda": "Arbeitswochen-Agenda",
      "monthAgenda": "Monatsagenda",
      "today": "Heute",
      "noEvents": "Keine Ereignisse",
      "emptyContainer": "An diesem Tag sind keine Veranstaltungen geplant.",
      "allDay": "Den ganzen Tag",
      "start": "Start",
      "end": "Ende",
      "more": "Mehr",
      "close": "Schließen",
      "cancel": "Stornieren",
      "noTitle": "(Kein Titel)",
      "delete": "Löschen",
      "deleteEvent": "Diese Veranstaltung",
      "deleteMultipleEvent": "Mehrere Ereignisse löschen",
      "selectedItems": "Elemente ausgewählt",
      "deleteSeries": "Ganze Serie",
      "edit": "Bearbeiten",
      "editSeries": "Ganze Serie",
      "editEvent": "Diese Veranstaltung",
      "createEvent": "Erstellen",
      "subject": "Gegenstand",
      "addTitle": "Titel hinzufügen",
      "moreDetails": "Mehr Details",
      "save": "speichern",
      "editContent": "Wie möchten Sie den Termin in der Serie ändern?",
      "deleteContent": "Möchten Sie diesen Termin wirklich löschen?",
      "deleteMultipleContent": "Möchten Sie die ausgewählten Ereignisse wirklich löschen?",
      "newEvent": "Neues Event",
      "title": "Titel",
      "location": "Ort",
      "description": "Beschreibung",
      "timezone": "Zeitzone",
      "startTimezone": "Starten Sie die Zeitzone",
      "endTimezone": "Zeitzone beenden",
      "repeat": "Wiederholen",
      "saveButton": "speichern",
      "cancelButton": "Stornieren",
      "deleteButton": "Löschen",
      "recurrence": "Wiederholung",
      "wrongPattern": "Das Wiederholungsmuster ist ungültig.",
      "seriesChangeAlert": "Möchten Sie die an bestimmten Instanzen dieser Serie vorgenommenen Änderungen verwerfen und erneut mit der gesamten Serie abgleichen?",
      "createError": "Die Dauer des Ereignisses muss kürzer als die Häufigkeit sein, mit der es auftritt. Verkürzen Sie die Dauer oder ändern Sie das Wiederholungsmuster im Wiederholungsereignis-Editor.",
      "sameDayAlert": "Zwei Ereignisse desselben Ereignisses können nicht am selben Tag auftreten.",
      "editRecurrence": "Wiederholung bearbeiten",
      "repeats": "Wiederholt",
      "alert": "Warnen",
      "startEndError": "Das ausgewählte Enddatum liegt vor dem Startdatum.",
      "invalidDateError": "Der eingegebene Datumswert ist ungültig.",
      "blockAlert": "Ereignisse können nicht innerhalb des gesperrten Zeitbereichs geplant werden.",
      "ok": "In Ordnung",
      "yes": "Ja",
      "no": "Nein",
      "occurrence": "Auftreten",
      "series": "Serie",
      "previous": "Bisherige",
      "next": "Nächster",
      "timelineDay": "Timeline Day",
      "timelineWeek": "Timeline-Woche",
      "timelineWorkWeek": "Timeline Work Week",
      "timelineMonth": "Timeline-Monat",
      "timelineYear": "Timeline-Jahr",
      "editFollowingEvent": "Folge Veranstaltungen",
      "deleteTitle": "Ereignis löschen",
      "editTitle": "Ereignis bearbeiten",
      "beginFrom": "Beginnen Sie von",
      "endAt": "Ende um"
    },
    "recurrenceeditor": {
      "none": "Keiner",
      "daily": "Täglich",
      "weekly": "Wöchentlich",
      "monthly": "Monatlich",
      "month": "Monat",
      "yearly": "Jährlich",
      "never": "noch nie",
      "until": "Bis um",
      "count": "Anzahl",
      "first": "Zuerst",
      "second": "Zweite",
      "third": "Dritte",
      "fourth": "Vierte",
      "last": "Zuletzt",
      "repeat": "Wiederholen",
      "repeatEvery": "Wiederhole jeden",
      "on": "Wiederholen Sie Ein",
      "end": "Ende",
      "onDay": "Tag",
      "days": "Tage)",
      "weeks": "Wochen)",
      "months": "Monat (e)",
      "years": "Jahre)",
      "every": "jeden",
      "summaryTimes": "mal)",
      "summaryOn": "auf",
      "summaryUntil": "bis um",
      "summaryRepeat": "Wiederholt",
      "summaryDay": "Tage)",
      "summaryWeek": "Wochen)",
      "summaryMonth": "Monat (e)",
      "summaryYear": "Jahre)",
      "monthWeek": "Monat Woche",
      "monthPosition": "Monatliche Position",
      "monthExpander": "Monats-Expander",
      "yearExpander": "Year Expander",
      "repeatInterval": "Wiederholungsintervall"
    },
    "calendar": {
      "today": "Heute"
    },
  }
});
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  providers: [DayService, WeekService, WorkWeekService, MonthService, AgendaService, ResizeService, DragAndDropService],
  encapsulation: ViewEncapsulation.None
})
export class AppComponent implements OnInit {
  @ViewChild('schedule')
  public scheduleObj: ScheduleComponent;
  public selectedDate: Date = new Date(2018, 1, 15);
  ngOnInit(): void {
    this.scheduleObj.locale = 'de';
  }
}